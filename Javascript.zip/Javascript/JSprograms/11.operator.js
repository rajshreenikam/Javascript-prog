function add_three_number(no1,no2,no3){
var addition= no1 + no2 + no3;
console.log(`Addition= ${addition}`);
}
add_three_number(10,20,30);

var number1 =100;
var number2 =40;
var result= number1 + number2;
console.log(`addition = ${result}`);

var num1 = 100;
var num2 = 41;

var result = num1 % num2;
var res = num2 % 2;
console.log(`Result ${res}`);

console.log(`Result ${num1%2}`);

var given_number =  5;
var add_1 = ++given_number;  //given_number + 1; 
console.log(`Pre incremented ${add_1}`);

var given_number =  5;
var add_1 = given_number++;  //given_number + 1; 
console.log(`post incremented ${add_1}`);


var num1 = 100;
var num2 = 41;
console.log(`== operator ${num1 == num2}`);

console.log(` != Operator  ${num1 != num2}`);

console.log(` > Operator  ${num1 > num2}`); // > greater than

console.log(` < Operator  ${num1 < num2}`); // < less than

console.log(` <= Operator  ${num1 <= num1}`); // <= less than equal

console.log(` >= Operator  ${num2 >= 41}`); // >= greater than equals

 // var bool_result = true && false;    // AND - &&   OR - ||    NOT - !
 var boolean_1 = false;
 var boolean_2 = true;

 console.log(` AND Operator  ${boolean_1 && boolean_2}`);  // AND - &&

 console.log(` OR Operator  ${boolean_1 || boolean_2}`); //  OR - || 

 console.log(` NOT Operator  ${!boolean_2}`);  // NOT - !
