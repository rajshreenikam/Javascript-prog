const endDate = "25 March 2023 8:29 PM";

document.getElementById("end-date").innerText=endDate;
const inputs = document.getElementsByTagName("input")

function clock(){
    const end = new Date(endDate);
    const now = new Date();
    console.log(end);
    console.log(now);
    const diff = (end - now) / 1000;// divide by 1000 to convert milisec to sec
    console.log(diff);
    
    if(diff < 0) return;
     // convert into days
     console.log("Days",Math.floor(diff / 3600 / 24));
     inputs[0].value = Math.floor(diff / 3600 / 24);
     //convert in to hours
     console.log("Hours",Math.floor(diff / 3600 % 24));
     inputs[1].value = Math.floor(diff / 3600 % 24);
     //convert in to minutes
     console.log("Minutes",Math.floor(diff / 60 % 60 ));
     inputs[2].value = Math.floor(diff / 60 % 60);
     //convert into seconds
     console.log("Seconds",Math.floor(diff % 60) );
     inputs[3].value = Math.floor( diff % 60);
}
clock();

// 1 day= 24hr
// 1hr= 60 min
// 60 min=1600 sec

setInterval(function (){
    clock()
},1000);;