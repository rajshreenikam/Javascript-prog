function x(){
  console.log("welcome");
}

function y(x){
     x();
}
