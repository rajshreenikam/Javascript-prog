// console.log(1);
// setTimeout(()=>{
//  console.log(2);
// },0)
// console.log(3);

var a={
    b:10,
    c:20,
    d:{
        e:30,
        f:40
    }
}
var { d,...x}=a
console.log(d);
console.log(x);