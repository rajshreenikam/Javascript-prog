const cart=["shoes","dress","kurta"];

const promise = createOrder(cart);// orderId
console.log(promise);

promise.then(function(orderId){
    console.log(orderId);
    // proceddToPayment(orderId)
    return orderId
})
promise.then(function(orderId){
    return proceedToPayment(orderId)
})
.then(function (paymentInfo){
    console.log(paymentInfo);
})

.catch(function(err){
    console.log(err.message);
})
.then(function (){
    console.log("i will definately call");
})


function createOrder(cart){
    const pr= new Promise(function (resolve, reject){
        if(!validateCart(cart)){
          const err=new Error("Cart is not Valid");
            reject(err);
        }
         // create order
         const orderId="1234";
         if(orderId){
            setTimeout(function() {
                resolve(orderId);
            }, 5000);
        }
    });

    return pr;
}

function proceedToPayment(){
    return new Promise(function(resolve,reject){
        resolve("Payment Successfully done");
    })
}
function validateCart(cart){
    return true;
}