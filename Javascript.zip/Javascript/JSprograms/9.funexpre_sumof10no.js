console.log(`--------- sum of first 10 no using function expression --------------`);
var sum= function (){
    var i=1;
    var result=0;
    while(i<=10){
        var result= result+i;
        i++;
    }
    console.log(` `);
    console.log(` Sum of 1 to 10 number is= ${result}`);
}
sum();