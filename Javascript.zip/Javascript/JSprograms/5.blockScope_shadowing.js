// var a=100;
// {
//     var a=10;
//     let b=20;
//     const c=30;
//     console.log("a=",a); //10
//     console.log("b=",b);//20
//     console.log("c=",c);//30
// }
// console.log("a=",a);//10



// let b=100;
// {
//     var a=10;
//     let b=20;
//     const c=30;
//     console.log("a=",a); //10
//     console.log("b=",b);//20
//     console.log("c=",c);//30
// }
// console.log("b=",b);//100


const c=100;
function x(){
    const c=30;
    console.log("inside function",c);  //30
}
x();
console.log(c);//100




const a=400;
{
const a=200;
{
    const a=300;
    console.log(a); //300
}
console.log(a);//200
}
console.log(a);//400
