// break
index=0;
while(index<=10){
    if(index==5){
    break;
}
    console.log(index);
    index++;
}
console.log(`after loop`);
// continue
index=0;
while(index<=10){
    index++;
    if(index==5){
    continue;
}
    console.log(index);
    
}
console.log(`after loop`);


for (let index = 0; index <= 5; index++) {
    console.log(`before continue`, index);
   if (index==2){
    continue;
   }
   console.log(`after continue`, index);  
}
console.log(`after for loop`);


