console.log("start");

setTimeout(function cb(){
    console.log("callback");
},0)

console.log("end");