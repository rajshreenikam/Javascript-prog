console.log(`---------- function to sum of square numbers from 1 to 5 --------`);
function sum_square(){
    var result=0;
    var sum=0;
    for(i=1; i<=5;i++){

        var result=i*i;                 
        var sum=sum+result;
    }
    console.log(``);
    console.log(`sum of square numbers from 1 to 5 is: ${sum}`);
}
sum_square();