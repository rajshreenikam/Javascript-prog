function grading(grade) {
    if (grade == null || grade == undefined || isNaN(grade) || typeof (grade) == "string") {
        console.log(`${grade} is invalid`);
    } else {
        if (grade < 35) {
            console.log(`your Percentage is ${grade} oooops you are fail`);
        }
        if (grade == 35) {
            console.log(`your Percentage is ${grade} you are passed`);
        }
        if (grade > 35 && grade <= 60) {
            console.log(`your Percentage is ${grade} your grade is C`);
        }
        if (grade > 60 && grade <= 75) {
            console.log(`your Percentage is ${grade} your grade is B`);
        }
        if (grade > 75 && grade <= 90) 
        {
            console.log(`your Percentage is ${grade} your grade is A`);
        } 
        if (grade > 90 && grade <= 100 ) 
        {
            console.log(`your Percentage is ${grade} your grade is A+`);
        }
    }
}
grading(45);
console.log(`--------------------------------------------------------------`);
grading(null);
console.log(`--------------------------------------------------------------`);
grading(90);
console.log(`--------------------------------------------------------------`);
grading(34);
console.log(`--------------------------------------------------------------`);
grading(undefined);
console.log(`--------------------------------------------------------------`);
grading(0);
console.log(`--------------------------------------------------------------`);
grading(67);
console.log(`--------------------------------------------------------------`);
grading(NaN);
console.log(`--------------------------------------------------------------`);