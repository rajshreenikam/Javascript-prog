function reverseString(str) {
    let ReversString=str.split("").reverse().join("");
    console.log("Reverse String is =" ,ReversString);
}
reverseString("hello");