console.log(`------Count Total vowels in "I love Javascript" using while ----------`);
var str="I love Javascript";
var index = 0;
var vowel_count = 0;
while(index<=str.length){
    var char = str.charAt(index);
    if(char =="a" || char == "A" || char =="e" || char =="E" || char =="i" || char =="I"|| char =="o"|| char =="O"|| char =="u"|| char =="U")
     {
        vowel_count++;
    }
    index++;
}
console.log(``);
console.log(`Total vowels in "I love Javascript" is: ${vowel_count}`);