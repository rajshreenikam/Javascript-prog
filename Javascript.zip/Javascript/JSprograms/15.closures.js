// function x(){
//  var a=7;
// function y(){
//    console.log(a);
// }
// y();
// }
// x();


// function outer(){
//    var a=10;
//    function inner(){
//       console.log(a);
//    }
//    return inner;
// }
//  var close=outer();
//  close();
 //10


//  function outer(){
   
//    function inner(){
//       console.log(a);
//    }
//    var a=10;
//    return inner;
// }
//  var close=outer();
//  close();
 //10


 function outer(b){
   
   function inner(){
      console.log(a,b);
   }
   var a=10;
   return inner;
}
 var close=outer("hello World");
 close();
// 10 hello World