var age=30; //number
console.log(age);

var name="rajshree nikam";// string
console.log(name);

var isMarried=true; // boolean
 console.log(isMarried);

 var price=85.20;
 console.log(price);

 var cup; //undefined
 console.log(cup);

 var no=null;//null
 console.log(no);



 

