const arr=[5,4,6,3,2]
// map method
console.log("---------------Map Method------------");
function double(x){
    return x * 2
}
function triple(x){
    return x * 3
}
function binary(x){
    return x.toString(2)
}
let output=arr.map(double)
console.log("double array elements [5,4,6,3,2]=",output);
let output1=arr.map(triple)
console.log("triple array elements [5,4,6,3,2]=",output1);
let binaryConversion=arr.map(binary)
console.log("binary conversion of array elements [5,4,6,3,2]=",binaryConversion);

// filter method
console.log("---------------filter Method------------");
function isOdd(x){
    return x % 2;
}

let oddNumbers=arr.filter(isOdd)
console.log("Odd Numbers array elements [5,4,6,3,2]=",oddNumbers);

function isEven(x){
    return x % 2===0;
}

let evenNumbers=arr.filter(isEven)
console.log("even Numbers array elements [5,4,6,3,2]=",evenNumbers);

function greaterThan4(x){
    return x > 4;
}
let greaterThan4No=arr.filter(greaterThan4)
console.log("number grater than 4 from array elements [5,4,6,3,2]=",greaterThan4No);


console.log("---------------reduce Method------------");
// Traditional function
function sum(arr){
    let sum=0;
    for(let i=0;i<arr.length;i++){
        sum = sum+arr[i];
    }
    return sum;
}
console.log(sum(arr));

// sum of array using reduce method
 const sumofArray=arr.reduce(function(acc,curre){
    acc=acc+curre
    return acc;
 },0);
 console.log("sum of array=",sumofArray);


//find maximum no

function maxNo(arr){
    let max=0;
    for(let i=0;i<arr.length;i++){
        if(arr[i]>max)
        max=arr[i];
    }
    return max
}
console.log(maxNo(arr));

// reduce method

let maxNumber=arr.reduce(function (maximum,curr){
    if(curr>maximum){
        maximum=curr;
    }
    return maximum;
},0);
console.log("Maximum Number",maxNumber);