const users=[
    {firstName:"Rajshree", lastName:"Bhosale", age:20},
    {firstName:"Meena", lastName:"Amar", age:30},
    {firstName:"Teena ", lastName:"Bhaskar", age:20},
    {firstName:"Ram", lastName:"Jeena", age:50},
];

// list of full name of users

let output=users.map(function name(x){
    return x.firstName + " " + x.lastName
})
console.log(output);

// people has same age

const CountOfSameAge=users.reduce(function (acc,curr){
   if(acc[curr.age]){
     acc[curr.age]=++acc[curr.age];
   }
   else
   {
    acc[curr.age]=1;
   }
   return acc;
},{})

console.log(CountOfSameAge);

// name of people whose age is less than 30 using filetr and map

const output1=users.filter((x)=>x.age<30).map((x)=>x.firstName)
console.log("name of people whose age is less than 30=",output1);

// name of people whose age is less than 30 using  reduce


const output4 = users.reduce(function (acc, min) {
    if (min.age < 30) {
      acc = [...acc, min.firstName];
    }
    return acc;
  }, []);
  console.log(output4);