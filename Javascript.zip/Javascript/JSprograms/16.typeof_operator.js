//typeof operator
//syntax: typeof value  or typeof(30)
// syntax: typeof my_name or typeof(my_name)
 
console.log("----------------------------------------------");

var my_name="Rajshree";
console.log("My Name is : "+ my_name + "  Type is :"+typeof my_name);
var mobile_no=9852245621;
console.log("My mobile number is : "+ mobile_no + "  Type is :"+typeof mobile_no);
var is_graduated= true;
console.log("Are you graduated : "+ is_graduated + "  Type is :"+typeof is_graduated);
console.log("----------------------------------------------");
 var college_name="KBP College";
 console.log("My College Name is : "+ college_name + "  Type is :"+ typeof college_name);
 var is_married= true;
 console.log("are you married : "+ is_married + "  Type is :"+ typeof is_married);
 var child= true;
 console.log("You have child : "+ child + "  Type is :"+ typeof child);
 var number=33.33;
 console.log("Number is : "+ number + "  Type is :"+ typeof number);
 console.log("----------------------------------------------");
 console.log("*** Special Data type ***");
 console.log("----------------------------------------------")
 var address=null;
 console.log("Address is : "+ address  + "  Type is :"+ typeof address);
 var hobbies;
 console.log("Hobbies is : "+ hobbies  + "  Type is :"+ typeof hobbies);
