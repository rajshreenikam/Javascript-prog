let array=[1,34,54,6,76,4,5,45,67]
 array.sort((a,b)=>{
    return a>b?1:-1;
 })
 console.log(array);
 let largetsno=array[array.length-1];
 console.log(`largest no ${largetsno}`);

 let smallestno=array[0];
 console.log(`smallest no ${smallestno}`);
