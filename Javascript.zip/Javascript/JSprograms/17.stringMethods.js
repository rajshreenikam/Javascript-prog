// String Methods

//charAt()
var greet ="Good Morning";
 var char=greet.charAt(3);
 console.log("character index of 4 is "+ char);
 
// concat()
 var fname="Rajshree ";
 var lname="Nikam";
 var concat=fname.concat(lname);
 console.log("Concatinate string " +concat);

 //indexof
 // for repeated char first occurance of char index no return
 // if character is not in string then it return -1
 var position=greet.indexOf("M");
 console.log("index position of M " + position);
 
// conversion in uppercase
 var upper=greet.toUpperCase();
 console.log("String in uppercase " + upper);

 // conversion in lowercase
 var lower=greet.toLowerCase();
 console.log("String in uppercase " + lower);


// to remove space use trim method

var lname=" nikam  ";
console.log("Before trim length "+ lname.length);
var trimmedString=lname.trim();
console.log("After trim length " +trimmedString.length);

//substring

var message="hi all dear friends";
var search=message.search("hi");
console.log(search);

var slice = greet.slice(5,10)
console.log(slice);

var substring = greet.substring(5,9)
console.log(substring);

var greet="hello good morning"
var words=greet.split(" ");
console.log(words);
console.log(words.length);



