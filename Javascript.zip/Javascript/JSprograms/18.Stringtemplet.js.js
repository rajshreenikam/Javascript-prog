
//Assignment 1
function string_templet_assignment()
{
console.log(`--------------------------------------------------------------------------------------------------------------`);
var hobby1=`Exploring new things`;
var hobby2="Searching on internet";
var hobby3="Playing";
console.log(`My First hobby is : ${hobby1}`);
console.log(`My Second hobby is :${hobby2}`);
console.log(`My Third hobby is : ${hobby3}`);
console.log(`---------------------------------------------------------------------------------------------------------------`);
console.log(`My hobbies are 1. ${hobby1} 2. ${hobby2} 3. ${hobby3}`);
console.log(`---------------------------------------------------------------------------------------------------------------`);
}
string_templet_assignment();

//Assignment 2
function string_methods_assignment()
{
console.log(`---------------------------------------------------------------------------------------------------------------`);
var message="  Hey you are doing good, keep it up  ";
console.log(`1. Original String is : ${message}`);

console.log(`---------------------------------------------------------------------------------------------------------------`);
var original_length=message.length;
console.log(`2. The original length of string is : ${original_length}`);

console.log(`---------------------------------------------------------------------------------------------------------------`);
var trimed_message=message.trim();
console.log(`3. Removing the leading & tailing extra spaces : ${trimed_message}`);
var trimed_msg_length=trimed_message.length;

console.log(`---------------------------------------------------------------------------------------------------------------`);
var total_removed_space=original_length - trimed_msg_length;
console.log(`4. Total no. of spaces removed from original string : ${total_removed_space} `);

console.log(`---------------------------------------------------------------------------------------------------------------`);
var first_char=trimed_message.charAt(0);
var last_char=trimed_message.charAt(trimed_message.length-1);
console.log(`5. First character  : ${first_char} , Last character : ${last_char} `);

console.log(`---------------------------------------------------------------------------------------------------------------`);
 var words=trimed_message.split(" ");
 var words_count=words.length;
 console.log(`6.Total no. of words in string :${words_count}`);

console.log(`---------------------------------------------------------------------------------------------------------------`);
var index_no=trimed_message.indexOf("good");
console.log(` 7. Index of word good :${index_no}`);

console.log(`---------------------------------------------------------------------------------------------------------------`);
var sub_string=trimed_message.substring(22);
console.log(` 8. Substring  starting from index 22 :${sub_string}`);

console.log(`---------------------------------------------------------------------------------------------------------------`);
var end_word=trimed_message.endsWith("up");
console.log(` 9. Is string end with word "up" :${end_word}`);

console.log(`---------------------------------------------------------------------------------------------------------------`);
var start_word=trimed_message.startsWith("Hey");
console.log(` 10. Is string starts with word "Hey" :${start_word}`);

console.log(`---------------------------------------------------------------------------------------------------------------`);
var last_index=trimed_message.lastIndexOf("y");
console.log(` 11.  Last index of y:${last_index}`);
}
string_methods_assignment();
