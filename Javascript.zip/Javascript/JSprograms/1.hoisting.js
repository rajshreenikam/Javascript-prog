// Hoisting In javascript


//  var x=7;
//  function getName(){
//     console.log("Welcome Javascript");
//  }
//  console.log("Value of x is ",x);   //value 0f is 7
//  getName();   //Welcome Javascript

 


console.log("Value of x is ",x);// undefined
console.log("Value of z is ",z);//ReferenceError: Cannot access 'z' before initialization
console.log("Value of y is ",y);//ReferenceError: Cannot access 'y' before initialization
getName(); //Welcome Javascript
console.log(getName); // it will log function as it is
getName1() //getName1() //ReferenceError: getName2 is not defined
getName2()// getName2()//TypeError: getName2 is not a function

var x=7;
let y=10;
const z=20;

function getName(){
   console.log("Welcome Javascript");
}

var getName1 = function (){
    console.log("welcome in fucntion expression");
}

var getName2 =()=>{
    console.log("Welcome in arrow function");
}


 