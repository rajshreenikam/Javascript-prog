
// object destructuring
const bioData={
    name:"rajshree",
    age:30,
    deg:'MSC',
    hobbi:{
        first:'playing',
        second:'reading'
    }
}
// console.log(`my name is ${bioData.name}`);

let {age,deg,name:myname,hobbi}=bioData;
console.log(`my name is ${myname}. my age is ${age}. My qualification is ${deg} i love to ${hobbi.first}`);