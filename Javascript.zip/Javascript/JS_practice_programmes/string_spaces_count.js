function stringSpaces(str){

    let count=0;
    for(let i=0;i<str.length;i++)
    {
      if(str[i]==" ")
      {
        count++
      }
    }
    console.log(`spaces in to sting ${count}`);
    let noofwords= count + 1;
     console.log(`Total Words in string ${noofwords}`);
}
stringSpaces("i am leaning Javascript");
