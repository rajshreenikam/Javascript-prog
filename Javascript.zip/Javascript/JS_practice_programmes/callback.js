 function do_homework(callback){
    console.log("doing homework");
    console.log("completed");
    callback();
 }
 function copy_homework(){
    console.log("copying homeowrk");
 }
 do_homework(copy_homework);