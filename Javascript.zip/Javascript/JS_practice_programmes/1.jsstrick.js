// var x=1;
// let y=1;
//  if(true){
//     var x=2;
//     let y=2;
//  }

// console.log(x);
// console.log(y);


// const animal=['pig','goat','ship'];

// console.log(animal.slice(2));
//  const count=animal.push('cow');
//  const newanimal=animal.concat('chicken','cat','dog');
//  console.log(newanimal);



//  const fruit=['mango','apple','banana']
// fruit.splice(1,0,'strawebery');
// console.log(fruit);


// const array=[1,2,3,4]
// console.log(array.fill(0,2,4));


// const array=[5,12,8,130,44,13]
// const found=array.find(Element=>Element>10)
// console.log(found);


// console.log(Array.from([1,2,3],x=>x+x));


// const array=[1,2,3]
// console.log(array.includes(2));

// const array=['shoes','shirt','socks','sweater']
// var name=array[array.length-1]
// console.log(name);


// const array=[1,4,9,16]
// var map1=array.map(x=>x*2);
// console.log(map1);


// const element=['fire','air','water']
// console.log(element.join());


// const plants=['a','b','c','d'];
// console.log(plants.pop());

// function precise(x){
//     return Number.parseFloat(x).toPrecision(4);
// }
// console.log( precise(123.456));

// console.log(Math.ceil(-7.674));


// var a={a:1,b:4,c:7}
// var i=Object.keys(a).length;
// console.log(i);


// const person={
//     fname:'john',
//     lname:'doe'
// }
// delete person.fname;
// console.log(person);


const sentense='The quick brownfox jumps over the lazydog';
const index=5;
console.log(`the char at index ${index} is ${sentense.charAt(index)}`);