let cars = [
    {
      "color": "purple",
      "type": "minivan",
      "registration": new Date('2017-01-03'),
      "capacity": 7
    },
    {
      "color": "red",
      "type": "station wagon",
      "registration": new Date('2018-03-03'),
      "capacity": 5
    },
     
  ]

  let car = {
    "color": "red",
    "type": "cabrio",
    "registration": new Date('2016-05-02'),
    "capacity": 2
  }
 cars.unshift(car);
// cars.push(car)
// cars.splice(1, 0, car);
// console.log(cars);

// let car1=cars.find(car=>car.color==="red" && car.type==="station wagon")
// console.log(car1);
  
let redCars = cars.filter(car => car.color === "red");
console.log(redCars);