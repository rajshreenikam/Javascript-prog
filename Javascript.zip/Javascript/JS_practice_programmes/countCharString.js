function charCount(str){
    let count=1;
    for(let i=0;i<str.lenght;i++)
    {
       if(str[i]===str[i+1])
       {
         count++;
       }
       else
       {          
        console.log(`${str[i]} occures ${count} times`);
         count=1;
       }
    }
}
charCount("rajshree");

 