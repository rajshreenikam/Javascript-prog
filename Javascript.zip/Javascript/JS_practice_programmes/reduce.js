let array=[1,2,3,4,5,6];
let array1=array.reduce((sum,value)=>{
    return sum + value;
})
console.log(array1);


let array2=array.filter((value)=>{
    return value % 2==0
}).reduce((sum,no)=>{
      return sum + no;
})
console.log(array2);

