
setTimeout(function timer(){
    console.log("hi welcome after 5 sec:");
},5000);

console.log("hi all");


setTimeout(function timer1(){
    console.log("hi welcome after 2 sec:");
},2000);

console.log("hi everyone");