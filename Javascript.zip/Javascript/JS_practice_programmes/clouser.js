var a=10;
function outer(){
    let b=20;
    function inner(){
        const c=30;
        console.log(`global var` ,a);
        console.log(`outer fun var` ,b);
        console.log(`local var` ,c);
    }
    return inner();
}
 return outer();