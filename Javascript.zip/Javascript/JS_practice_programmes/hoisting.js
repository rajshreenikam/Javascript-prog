// using test before declaring
// console.log(test);   // undefined
// var test;

// program to display value
// a = 5;
// console.log(a);
// var a; // 5

//However in JavaScript, initializations are not hoisted. 
// program to display value
// console.log(a);
// var a = 5; // undefined

 

// function greet() {
//     b = 'hello';
//     console.log(b); // hello
//     var b;
// }

// greet();  
// console.log(b); // ReferenceError: b is not defined



// // program to display value
// a = 5;
// console.log(a);// error ReferenceError: Cannot access 'a' before initialization
// let a; 

// program to print the text
// greet();
// function greet() {
//     console.log('Hi, there.');
// }

// program to print the text
// greet();

// let greet = function() {
//     console.log('Hi, there.'); //ReferenceError: Cannot access 'greet' before initialization
// }

// program to print the text
// greet();

// var greet = function() {
//     console.log('Hi, there.'); //TypeError: greet is not a function
// }