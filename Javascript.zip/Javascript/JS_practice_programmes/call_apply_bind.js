let printfullName=function(hometown,state){
    console.log(this.fname+" "+this.lname+" "+hometown+" "+state);
 }
let person1={
    fname:"mack",
    lname:"joseph", 
}
let person2={
    fname:"sachin",
    lname:"tendulkar",
    
}
printfullName.call(person1,"satara","MH");
printfullName.apply(person2,["mumbai",'MH']);
let printname=printfullName.bind(person1,"satara","MH");
console.log(printname);
printname();