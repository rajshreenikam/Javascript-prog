// function reverse(str){
//     return str.split("").reverse().join("")
// }
// console.log(reverse("I am Angular Developer"));


function reverse(str){
    return [...str].reverse().join("");
}
console.log(reverse("I am Angular Developer"));