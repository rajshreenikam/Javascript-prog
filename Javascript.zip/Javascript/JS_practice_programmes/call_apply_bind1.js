 let fullname=function(country,age){
    console.log(`${this.fname} ${this.lname}, age=${age}, country= ${country}`);
}
 
 
 let person1={
    fname:"mariya",
    lname:"sharapoa",
   
 }
//  person1.fullname();

 let person2={
    fname:"gill",
    lname:"cris",
   
 }
//   fullname.call(person1,'US','30');
//   fullname.call(person2,'India','35');

// fullname.apply(person1,['US','30']);
// fullname.apply(person2,['India','35']);

let name1=fullname.bind(person1,'US','30');
 console.log(name1);
 name1();