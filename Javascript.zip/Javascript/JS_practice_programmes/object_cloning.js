// let car={
//     color:"pink",
//     brand:"tata"
// }
// let vehicle=car; //shallow copy
// console.log(`car object ${car.color} ${car.brand}`);
// console.log(`vehicle object ${vehicle.color} ${vehicle.brand}`);
// vehicle.color="purple";
// console.log(`car object ${car.color} ${car.brand}`);
// console.log(`vehicle object ${vehicle.color} ${vehicle.brand}`);


// let vehical1={...car} // deep copy
// console.log(`car object ${car.color} ${car.brand}`);
// console.log(`vehicle object ${vehicle.color} ${vehicle.brand}`);

// car.color="white";
// console.log(`car object ${car.color} ${car.brand}`);
// console.log(`vehicle1 object ${vehical1.color} ${vehical1.brand}`);

// nested object
let car={
    color:"pink",
    brand:"tata",
    model:{
        type:"PU123"
    }
}
// let vehicle2={...car}; // problem with netsed object using spread operator
// console.log(`car object ${car.color} ${car.brand} ${car.model.type}`);
// console.log(`vehicle object ${vehicle2.color} ${vehicle2.brand}  ${vehicle2.model.type}`);
// vehicle2.model.type="AB124";
// console.log(`car object ${car.color} ${car.brand} ${car.model.type}`);
// console.log(`vehicle object ${vehicle2.color} ${vehicle2.brand}  ${vehicle2.model.type}`);

let vehicle3=JSON.parse(JSON.stringify(car));
console.log(`car object ${car.color} ${car.brand} ${car.model.type}`);
console.log(`vehicle object ${vehicle3.color} ${vehicle3.brand}  ${vehicle3.model.type}`);
vehicle3.model.type="AB124";
 console.log(`car object ${car.color} ${car.brand} ${car.model.type}`);
 console.log(`vehicle object ${vehicle3.color} ${vehicle3.brand}  ${vehicle3.model.type}`);
