let array=[1,2,3,4,5,55,23,46,43];
array.sort((a,b)=>{
    return a>b ? 1:-1
})
console.log(array);