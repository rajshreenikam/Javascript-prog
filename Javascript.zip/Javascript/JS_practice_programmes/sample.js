// console.log(a);  //undefined
// var a;
// console.log(a);  //undefined
// a=10;
// console.log(a); //a=10
// a=30;
// console.log(a); //a=30


// b=10;
// console.log(b);
// var b;

//  a=10;
// console.log(a);  //error
//  let a;


// console.log(y); // undefined
// y = 1; 

// console.log(y); // y=1
// var y = 2;
 
// y = 3;
// console.log(y); // y=3
// var y;


// var z = 1;
// let z;
// console.log(z); //  Identifier 'z' has already been declared
 
// console.log(z); // Cannot access ‘z’ before initialization
// let z = 1;


// function hoistingExample() {  
//     console.log("Value of a in local scope: ", a); //1
//     } 
//     console.log("Value of a in global scope: ", a);// undefined
//     var a = 1;
//     hoistingExample();


// function hoistingExample() {   
//     a = 1;
//     } 
//     hoistingExample();
//     console.log(a);//ReferenceError: a is not defined


// function hoistingExample() {   
//     var a = 1;
//     } 
//     hoistingExample();
//     console.log(a);//ReferenceError: a is not defined


// function a(){
//     console.log("1")
//   }
//   a();
//   function a(){
//     console.log("2")
//   }
//   a();


