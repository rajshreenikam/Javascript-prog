let originalaArray=[1,55,43,56,78,345,67];

let copyArray=originalaArray;//shallow copy
console.log(originalaArray);
console.log(copyArray);
copyArray.push(15);
console.log(originalaArray);
console.log(copyArray);

let copyArray1=[...originalaArray]; // deep cloning
console.log(originalaArray);
console.log(copyArray1);
copyArray1.push(20);
console.log(originalaArray);
console.log(copyArray1);