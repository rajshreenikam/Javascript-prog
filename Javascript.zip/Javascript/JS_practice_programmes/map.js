let array=[1,4,76,88,908,665,34,23]
let new_array=array.map((value)=>{
    return value+2;
})
console.log(new_array);

let array1=array.map((value)=>{
    return value * value;
})
console.log(array1);