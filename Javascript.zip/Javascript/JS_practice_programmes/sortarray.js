let array=[1,2,3,4,5,6];
array.sort((a,b)=>{
    return a>b?1:-1;
});
console.log(array);
let gretestno=array[array.length-1]
console.log(gretestno);
let smallestno=array[0];
console.log(smallestno);

// sum of array element
let sumOfArray=array.reduce((value,sum)=>{
    return value+ sum;
});
console.log(sumOfArray);

//addition of even no
let addEvenNo=array.filter((value)=>{
    return value %2 ==0
}).reduce((sum,no)=>{
    return sum +no;
})
console.log(addEvenNo);


