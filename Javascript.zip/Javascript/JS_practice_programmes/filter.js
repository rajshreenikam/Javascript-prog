let array=[5,6,54,54,43,67,34,5,23,21,90];
let array1=array.filter((value)=>{
    return value >40;
})
console.log(array1);