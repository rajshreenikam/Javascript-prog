let sample=[1,2,3,4,2,3,55,4,44,3,2,4]
const  array=[...new Set(sample)]
console.log(array);