let array1=[1,2,3,4,5,6,7,8]
let evenarray=[];
for(i=0;i<array1.length-1;i++)
{
    if(array1[i] % 2 ==0)
    {
    evenarray.push(array1[i])
    }

}
console.log(evenarray);