let person=[
    { fname:"Amit",
      lname:"Nikam",
      state:"MH"
    },
    { fname:"bmit",
      lname:"Nikam",
      state:"UP"
    },
    { fname:"cita",
      lname:"Nikam",
      state:"MP"
    },
    { fname:"Zeeta",
      lname:"Nikam",
      state:"KR"
    },

]

console.log(person);
let sorted=person.sort((a,b)=>{

    return (a.state > b.state)?1:-1;
})
console.log("sorted by alphbetically");
console.log(sorted);