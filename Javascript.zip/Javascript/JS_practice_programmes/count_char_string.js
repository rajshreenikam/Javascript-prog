function count_char(str){
    let count=1;
    for(let i=0;i<str.length;i++)
    {
       if(str[i]===str[i+1])
       {
        count++;
       }
       else{
       console.log(`${str[i]} occures ${count} times`);
       count=1;
       }
    }
}
count_char("rajshree");


// function char_count(str, letter)
// {
//     count=0;
//     for(i=0;i<str.length;i++)
//     {
//         if(str[i]==letter)
//         {
//             count++;
//         }
//     }
//     console.log(`${count}`);
// }
// char_count(" i am learning Javascript","a");