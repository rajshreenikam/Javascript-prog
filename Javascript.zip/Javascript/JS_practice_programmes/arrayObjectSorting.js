let products = [
    {
      "product_name": "Witchers",
      "type": "book",
      "manufactured": new Date('2019-05-13'),
      "price": 800
    },
    {
      "product_name": "Black Heels",
      "type": "Shoes",
      "manufactured": new Date('2021-07-06'),
      "price": 2500
    },
 
  ]
  console.log("Original Products are:")
  console.log(products)
  let sortedProducts = products.sort(
      (p1, p2) => (p1.product_name > p2.product_name) ? 1 : (p1.product_name <p2.product_name) ? -1 : 0);
  
  console.log("Products sorted based on descending order of their prices are:")
  console.log(sortedProducts);