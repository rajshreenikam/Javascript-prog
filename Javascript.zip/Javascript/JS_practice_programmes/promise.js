let p=new Promise((resolve, reject)=>{
    console.log("promise is pending");
    setTimeout(function hello(){
        console.log("promise reject");
         reject(new Error);
    },3000)
});
p.then(sucess=>console.log(sucess))
.catch(reject=>console.log(" some error occure"))
.finally(()=>console.log("finally called"))