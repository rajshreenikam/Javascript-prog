console.log(`***********  print number from 5 to 15 ********************`);
for (let index = 5 ; index <= 15; index++){
   console.log(` ${index}`);
}
console.log(`***********  print numbers from 50 to 40 ********************`);
for (let index = 50 ; index >= 40; index--){
    console.log(`  ${index}`);
 }
 console.log(`*********** print first 15 of odd numbers ********************`);
for (let index = 1 ; index <=30; index=index+2){
    console.log(`  ${index}`);
 }
console.log(`*********** print first 10 even numbers ********************`);
for (let index = 0 ; index <=18; index=index+2){
    console.log(`  ${index}`);
 }

 console.log(`*********** print table of 5 ********************`);
for (let index = 5 ; index <=50; index=index+5){
    console.log(`  ${index}`);
 }
 console.log(`*********** print table of 10 ********************`);
for (let index = 10 ; index <=100; index=index+10){
    console.log(`  ${index}`);
 }