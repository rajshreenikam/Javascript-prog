console.log(`--------------50 to 40 using While loop  ----------------` );
var i=50;
while(i>=40){
      console.log(`${i}`);
      i--;
}
console.log(`--------------50 to 40  using do while loop ----------------` );
var a=50;
do{
    console.log(`${a}`);
    a--;
}
while(a>=40);