function even_position_char(string) {
    console.log(`Even positioned characters`);
    for (i = 0; i <= string.length; i++) {
        if (i % 2 == 0 ) {
            var char = string.charAt(i);
            if (char !== "") {
                console.log(`${string.charAt(i)}`);
            }
        }
    }
}

even_position_char("Hard work always pays back");
even_position_char("Soon I will be Angular It Champ");

// function even_position_char(string) {
//     console.log(`Even positioned characters`);
//     for (i = 0; i <= string.length; i++) {
//         if (i % 2 == 0 && char !== "") {
//             console.log(`${string.charAt(i)}`);
//         }
//     }
// }
// even_position_char("Hard work always pays back");
// even_position_char("Soon I will be Angular It Champ");