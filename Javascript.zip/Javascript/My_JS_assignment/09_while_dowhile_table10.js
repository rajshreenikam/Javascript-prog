console.log(`--------------Table of 10 number using while loop----------------` );
var i=10;
while(i<=100){
      console.log(`${i}`);
      i=i+10;
}
console.log(`--------------Table of 10 number using do while loop ----------------` );
var a=10;
do{
    console.log(`${a}`);
    a=a+10;
}
while(a<=100);