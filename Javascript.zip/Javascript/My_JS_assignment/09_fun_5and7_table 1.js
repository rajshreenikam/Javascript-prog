console.log(`------------ function to print table of 5 & 7 --------------- `);
function table(no)
{   
    
    for(i=1; i<=10; i++)
    {
        var result=no * i;
        console.log(`${no} * ${i} = ${result}`);
    }
    console.log(`-----------------------------------------------------------`);
}
table(5);
table(7);