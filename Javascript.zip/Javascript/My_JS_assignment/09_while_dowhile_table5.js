console.log(`--------------Table of 5 number using while loop----------------` );
var i=5;
while(i<=50){
      console.log(`${i}`);
      i=i+5;
}
console.log(`--------------Table of 5 number using do while loop ----------------` );
var a=5;
do{
    console.log(`${a}`);
    a=a+5;
}
while(a<=50);