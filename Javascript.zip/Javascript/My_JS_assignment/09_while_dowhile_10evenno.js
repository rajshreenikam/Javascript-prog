console.log(`--------------First 10 even number using while loop----------------` );
var i=2;
while(i<=20){
      console.log(`${i}`);
      i=i+2;
}
console.log(`--------------First 10 even number using do while loop ----------------` );
var a=2;
do{
    console.log(`${a}`);
    a=a+2;
}
while(a<=20);