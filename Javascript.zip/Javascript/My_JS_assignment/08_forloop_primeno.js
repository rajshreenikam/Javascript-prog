// prime number
function prime_number(prime){
    for (let index = 2; index < prime; index++) {
        if(prime % index != 0){
            return "not a prime number"
        }  
    }
    return "prime number"
}
prime_number(` is prime no ${prime_number(3)}`);
prime_number(` is prime no ${prime_number(4)}`);