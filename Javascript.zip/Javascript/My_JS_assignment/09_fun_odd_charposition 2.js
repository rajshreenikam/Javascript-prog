function even_position_char(string)
{
    for(i=0; i<=string.length-1;i++)
    {
        //  var char_positions= string.charAt(i);
     
           if(i % 2 !== 0)
           {
               var even_pos_char=string.charAt(i);
                if(even_pos_char !== ' ')
                {
                    console.log(`Even character: ${even_pos_char}  Characters index position: ${i}`);
                }

           }

    }
}console.log(`String after removing spaces: Hardworkalwayspaysback`);
even_position_char("Hard work always pays back");
 
console.log(`String after removing spaces  : SoonIwillbeAngularItChamp`);
even_position_char("Soon I will be Angular It Champ");