//simple factorial of program 
var result =1;
for (let index = 1; index <= 5; index++) {
     
    result = result * index; 
   
}
console.log(`factorial is ${result}`);

// function- factorial program
function factorial(number){
var result =1;
for (let index = 1; index <= number; index++) { 
    result = result * index; 
}
return result
}
console.log(`factorial is ${factorial(5)} `);
console.log(`factorial is ${factorial(6)} `);
